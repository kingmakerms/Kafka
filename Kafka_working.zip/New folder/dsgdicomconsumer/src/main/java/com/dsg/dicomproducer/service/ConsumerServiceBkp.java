//package com.dsg.dicomproducer.service;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.RandomAccessFile;
//import java.time.Duration;
//import java.util.Collections;
//import java.util.Properties;
//import org.apache.commons.lang.ArrayUtils;
//import org.apache.kafka.clients.consumer.Consumer;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.apache.kafka.clients.consumer.KafkaConsumer;
//import org.apache.kafka.common.config.SslConfigs;
//import org.apache.kafka.common.errors.SerializationException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.io.Resource;
//import org.springframework.core.io.ResourceLoader;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//import com.amazonaws.ClientConfiguration;
//import com.amazonaws.auth.AWSCredentials;
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicAWSCredentials;
//import com.amazonaws.client.builder.AwsClientBuilder;
//import com.amazonaws.services.s3.AmazonS3;
//import com.amazonaws.services.s3.AmazonS3ClientBuilder;
//@Service
//public class ConsumerServiceBkp {
//
//	@Autowired
//	ResourceLoader resourceLoader;
//
//
////	@KafkaListener(topics = "dsg_dicom_msg", groupId = "dicom-consumer-2")
////	@KafkaListener(topics = "dsg_dicom_image", groupId = "dicom-consumer-2")
//	public void consumeMessage(String name) throws IOException {
//
//		String successmsg = null;
//		
//		long filepoiter = 0;
//		
//		int i =0;
//		byte[] concatBytes=null;
//		
//		Resource resource = resourceLoader.getResource("classpath:producer.properties");
//
//		System.out.println("----resource test-- uri-------"+resource.getURI());
//
//		final Properties props = loadConfig(resource);
//
//		System.out.println("---CA pem loc------"+resourceLoader.getResource("classpath:ca.pem").getURI().getRawPath());
//
//		// Create topic if needed
//		final String topic = "dsg_dicom_msg";
//
//
//		// Add additional properties.
//		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, resourceLoader.getResource("classpath:ca.pem").getURI().getRawPath());
//		props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG,"PEM");
//
//		//props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
//		// props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.springframework.kafka.support.serializer.JsonDeserializer");
//		// props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//		//props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
//
//		//  props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, String.class);
//
//
//		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArrayDeserializer");
//		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArrayDeserializer");
//		//props.put(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG, "5023177");
//	    //props.put(ConsumerConfig.FETCH_MAX_BYTES_CONFIG, "5023177");
//		props.put(ConsumerConfig.GROUP_ID_CONFIG, "dicom-consumer-2");
//		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//		Consumer<String,  byte[]> consumer = new KafkaConsumer<>(props);
//
//		//subscribe to topic
//		consumer.subscribe(Collections.singleton("dsg_dicom_msg"));
//		//consumer.subscribe(Arrays.asList("dsg_dicom_msg"));  
//
//		//String filePath = "/home/vcap/app/dicom_output/output_daicom.jpg";
//		//RandomAccessFile file = new RandomAccessFile(filePath, "rw"); 
//		//new
//		//File inputStream1 = new File("/home/vcap/app/dicom_output/output_daicom.jpg");
//		FileOutputStream outputStream = new FileOutputStream("/home/vcap/app/dicom_output/output_daicom.jpg",true);
//		
//		//new 
//		try {
//
//			
//			while (true) {
//				ConsumerRecords<String,  byte[]> records = null;
//				try {
//
//					records = consumer.poll(Duration.ofMillis(100));
//
//					System.out.println("Records count" +records.count());
//				} catch (SerializationException e) {
////					String s = e.getMessage().split("Error deserializing key/value for partition ")[1].split(". If needed, please seek past the record to continue consumption.")[0];
////					String topics = s.split("-")[0];
////					int offset = Integer.valueOf(s.split("offset ")[1]);
////					int partition = Integer.valueOf(s.split("-")[1].split(" at")[0]);
////
////					TopicPartition topicPartition = new TopicPartition(topics, partition);
////					consumer.seek(topicPartition, offset + 1);
//				}
//
////				AmazonS3 amazonS3Client = getS3ClientForOnprem();
////				System.out.println("-------------AmazonS3 obj cretaed-----------------------------");
//
//
//
//  
//				
//				for (ConsumerRecord<String,  byte[]> record : records) {
//
//
//
//					System.out.printf("Consumed value = %s \n", record.value().length);
//
//					//successmsg = new String(record.value());
//					
//					//System.out.println("No of records received from producer"+record.key().toString());
//
//					// finalarray=record.value();
//					concatBytes = ArrayUtils.addAll(concatBytes,record.value());
//					//InputStream myInputStream = new ByteArrayInputStream(concatBytes); 
//					// new
//					/*
//					file.seek(filepoiter);
//					file.write(record.value());
//					filepoiter = file.getFilePointer();
//					*/
//					
//					int CurrentFilePointer = 0;
//					outputStream.write(record.value());
//					
//					
//					i++;
//					System.out.println("amazon-concatBytes-----i value---amazon-offset---amazon-partition----"+concatBytes.length+"----"+i+record.offset()+"------"+record.partition());
//					if(record.value().length==28177) {
//						 break;
//					}	
//					
//					
//					
//					//System.out.println("---amazon-key-"+record.key());
//
//
//					//amazonS3Client.putObject("cf-s3-7e260f71-274f-4607-afe3-ea2731bf2409", record.key().toString()+".jpg",myInputStream, null);
//
////					amazonS3Client.putObject("cf-s3-7e260f71-274f-4607-afe3-ea2731bf2409", name+".jpg",myInputStream, null);
//
//				} // end of for loop
//				
//				//AmazonS3 amazonS3Client = getS3ClientForOnprem();
//
//				//InputStream myInputStream = new ByteArrayInputStream(concatBytes); 
//
//				//amazonS3Client.putObject("cf-s3-7e260f71-274f-4607-afe3-ea2731bf2409", "dicom.jpg",myInputStream, null);
//
//				//amazonS3Client.putObject("cf-s3-7e260f71-274f-4607-afe3-ea2731bf2409", "dicom.jpg", concatBytes);
//				if(concatBytes!=null && concatBytes.length>=5023177) {
//					 break;
//				}
//		   
//			}//end while
//			
//
//
//
//
//		} finally {
//			outputStream.close();
//			consumer.close();
//		}
//
//
//		// System.out.printf("-------------------Consumeer before poll-------------");
//		/*
//		    Consumer<String, String> consumer = new KafkaConsumer<>(props);
//
//	        //subscribe to topic
//	        consumer.subscribe(Collections.singleton("dsg_dicom_msg"));
//
//	        //poll the record from the topic
//	        while (true) {
//	            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
//
//	            for (ConsumerRecord<String, String> record : records) {
//	                System.out.println("Consumed record: " + record.value());
//	            }
//	            consumer.commitAsync();
//	        }
//	}*/
//		/*
//
//    final Consumer<String, String> consumer = new KafkaConsumer<String, String>(props);
//    consumer.subscribe(Collections.singleton(topic));
//
//    System.out.printf("-------------------Consumeer before poll-------------");
//
//    try {
//      while (true) {
//        ConsumerRecords<String, String> records = consumer.poll(100);
//        for (ConsumerRecord<String, String> record : records) {
//
//
//          String value = record.value();
//
//         // User value = record.value();
//         // total_count += value.getName();
//          System.out.printf("Consumed record with and value"+ value);
//
//        // System.out.printf("Consumed record with key %s and value %s, and updated user name to %d%n", key, value, value.getName());
//        }
//      }
//    } finally {
//    	 consumer.commitAsync();
//      consumer.close();
//    }
//	}*/
//	}
//
//	private static byte[] readFromFile(File filePath, int seek, int data) throws IOException {
//		RandomAccessFile file = new RandomAccessFile(filePath, "r");
//		file.seek(seek);
//		byte[] bytes = new byte[data];
//		file.read(bytes);
//		file.close();
//		return bytes;
//	}
//	
//	public static synchronized AmazonS3 getS3ClientForOnprem() {
//
//
//		AWSCredentials credentials = new BasicAWSCredentials("JLwLOqTz",
//				"Dlb47Wk5BfKK8nxM");
//		ClientConfiguration clientConfiguration = new ClientConfiguration();
//		clientConfiguration.setSignerOverride("AWSS3V4SignerType");
//		return AmazonS3ClientBuilder.standard()
//				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("https://s3.cf.dsg.hsop.io",
//						"eu-central-1"))
//				.withPathStyleAccessEnabled(Boolean.TRUE).withClientConfiguration(clientConfiguration)
//				.withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
//	}
//
//
//	public static Properties loadConfig(final Resource configFile) throws IOException {
//		//		if (!Files.exists(Paths.get(configFile))) {
//		//			throw new IOException(configFile + " not found.");
//		//		}
//		//Resource resource = resourceLoader.getResource("classpath:android.png");
//		File file = configFile.getFile();
//		final Properties cfg = new Properties();
//		try (InputStream inputStream = new FileInputStream(file)) {
//			cfg.load(inputStream);
//		}
//		return cfg;
//	}
//
//}
