package com.dsg.dicomproducer.service;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Duration;
import java.time.Instant;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.core.io.ClassPathResource;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.dsg.dicomproducer.constants.DicomConsumerConstant;
import com.dsg.dicomproducer.controller.FileDownloadController;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ConsumerListenerService {

	@KafkaListener(topics = "dsg_dicom_pro2", groupId = "dicom-consumer-2")
	public void consume(ConsumerRecord<String, byte[]> record) {
		Instant startTime = Instant.now();
		RandomAccessFile output_file;
		try {
			output_file = new RandomAccessFile(DicomConsumerConstant.FILEPATH, "rw");
			output_file.seek(output_file.length());
			output_file.write(record.value());
			output_file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Instant endTime = Instant.now();
		calculateTime(startTime, endTime);

	}

	public String calculateTime(Instant startTime, Instant endTime) {
		File filePath;
		Long timeEla_sec = 0L;
		
		try {
			if (startTime != null && endTime != null) {
				Duration timeElapsed = Duration.between(startTime, endTime);
				timeEla_sec = timeElapsed.toMillis();
				DicomConsumerConstant.TIME_DIFFRENCE = DicomConsumerConstant.TIME_DIFFRENCE + timeEla_sec;
			}
			System.out.println(
					"startTime, endTime, timeEla_sec,DicomConsumerConstant.TIME_DIFFRENCE,DicomConsumerConstant.COUNT----"
							+ startTime + "-----" + endTime + "-----" + timeEla_sec + "-----"
							+ DicomConsumerConstant.TIME_DIFFRENCE + "-----" + DicomConsumerConstant.COUNT);
			if (DicomConsumerConstant.COUNT == 7) {
				String file_name = "jmm_4377_5mb.jpg";
				long file_size = 5023177L;
				if(DicomConsumerConstant.TIME_DIFFRENCE!=0)
				{
	
				DicomConsumerConstant.THROUGHPUT = file_size / DicomConsumerConstant.TIME_DIFFRENCE;
				}
				String return_str = "filename---" + file_name + "---" + "file_size---" + file_size + "Bytes---"
						+ "duration---" + DicomConsumerConstant.TIME_DIFFRENCE + "ms---" + "throughput(bpms)---"
						+ DicomConsumerConstant.THROUGHPUT;
				
				DicomConsumerConstant.TIME_DIFFRENCE = 0L;
				DicomConsumerConstant.THROUGHPUT = 0L;
				DicomConsumerConstant.COUNT = 0;
				log.info("--------------return_str------" +return_str);

				return return_str;
			} else {
				DicomConsumerConstant.COUNT++;
			}

			log.info("DicomConsumerConstant.COUNT-1-----" + DicomConsumerConstant.COUNT);
			System.out.println("DicomConsumerConstant.COUNT-1-----" + DicomConsumerConstant.COUNT);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("--------------after exception------");

		return null;
	}

}