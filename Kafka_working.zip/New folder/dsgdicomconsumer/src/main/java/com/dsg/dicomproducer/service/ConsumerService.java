package com.dsg.dicomproducer.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Properties;

import org.apache.commons.lang.ArrayUtils;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.errors.SerializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.dsg.dicomproducer.constants.DicomConsumerConstant;
import com.dsg.dicomproducer.dto.ImageData;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ConsumerService {

	@Autowired
	ResourceLoader resourceLoader;


	public ImageData consumeMessage(String name) throws IOException {

		String successmsg = null;

		long filepoiter = 0;

		Resource resource = resourceLoader.getResource("classpath:producer.properties");
		final Properties props = loadConfig(resource);

		//final String topic = "dsg_dicom_msg";
		final String topic = "dsg_dicom_proconsume";



		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, resourceLoader.getResource("classpath:ca.pem").getURI().getRawPath());
		props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG,"PEM");
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArrayDeserializer");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArrayDeserializer");

		props.put(ConsumerConfig.GROUP_ID_CONFIG, "dicom-consumer-2");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		Consumer<String,  byte[]> consumer = new KafkaConsumer<>(props);


		consumer.subscribe(Collections.singleton(DicomConsumerConstant.TOPIC_NAME));


		//String filePath = "/home/vcap/app/dicom_output/output_daicom.jpg";
		RandomAccessFile file = new RandomAccessFile(DicomConsumerConstant.FILEPATH, "rw");

		Instant startTime = Instant.now();
		
		log.info("------------startTime------------ "+startTime);
		try {
			long fileleng=0;

			while (true) {
				ConsumerRecords<String,  byte[]> records = null;
				try {

					records = consumer.poll(Duration.ofMillis(100));

				} catch (SerializationException e) {
					e.printStackTrace();
				}


				int i =0;
				byte[] concatBytes=null;

				for (ConsumerRecord<String,  byte[]> record : records) {

					concatBytes = ArrayUtils.addAll(concatBytes,record.value());
					file.seek(filepoiter);
					file.write(record.value());
					filepoiter = file.getFilePointer();
					i++;
					log.info("i++------------------"+i);
					log.info("key ----------------"+record.key().toString());

					fileleng= file.length();
					log.info("filelog size------------------"+file.length());
				} 
				if(filepoiter>=DicomConsumerConstant.FILE_BYTE) {
					break;
				}

			}
			log.info("final filesize-----------"+fileleng);

			Instant endTime = Instant.now();
			
			return calculateFileThroughput(startTime,endTime,fileleng,"image");

		} finally {
			file.close();
			consumer.close();
		}

	}

	public static Properties loadConfig(final Resource configFile) throws IOException {

		File file = configFile.getFile();
		final Properties cfg = new Properties();
		try (InputStream inputStream = new FileInputStream(file)) {
			cfg.load(inputStream);
		}
		return cfg;
	}

	public  ImageData calculateFileThroughput(Instant startTime,Instant endTime, long fileSize, String fileName) {

		Duration duration = Duration.between(startTime, endTime);
		log.info("---------------duration in milli-------------------"+duration.toMillis());

		long throughput =  fileSize / duration.toMillis();
		log.info("--------Throughput with milli---------------"+throughput);

		ImageData  data=new ImageData();
		data.setFileName(fileName);
		data.setFileSize(fileSize);
		data.setDuration(duration.toMillis());
		data.setStartTime(startTime);
		data.setEndTime(endTime);
		data.setThroughput(throughput);
		/*HashMap<String, Object> listData = new HashMap<String, Object>();
		listData.put("fileName", fileName);
		listData.put("fileSize(Bytes)", fileSize);
		listData.put("startTime",startTime);
		listData.put("endTime", endTime);
		listData.put("duration(MS)", duration.toMillis());
		listData.put("throughput(B/MS)", throughput);
		

		Set<Map.Entry<String, Object> > entrySet
		= listData.entrySet();
		ArrayList<Map.Entry<String, Object> > listOfEntry
		= new ArrayList<Entry<String, Object> >(entrySet);*/

		log.info("--------Throughput with milli------listOfEntry---------"+data.toString());

		return data;

	}
	
}
