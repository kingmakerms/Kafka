package com.dsg.dicomproducer.dto;

import java.time.Instant;



public class ImageData {
	
	
		private long id;

		private String fileName;

		private long fileSize;

		private Instant startTime;
		
		private Instant endTime;

		private long duration;
		
		private long throughput;

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public long getFileSize() {
			return fileSize;
		}

		public void setFileSize(long fileSize) {
			this.fileSize = fileSize;
		}

		public Instant getStartTime() {
			return startTime;
		}

		public void setStartTime(Instant startTime) {
			this.startTime = startTime;
		}

		public Instant getEndTime() {
			return endTime;
		}

		public void setEndTime(Instant endTime) {
			this.endTime = endTime;
		}

		public long getDuration() {
			return duration;
		}

		public void setDuration(long duration) {
			this.duration = duration;
		}

		public long getThroughput() {
			return throughput;
		}

		public void setThroughput(long throughput) {
			this.throughput = throughput;
		}

		@Override
		public String toString() {
			return "ImageData [fileName=" + fileName + ", fileSize=" + fileSize + ", startTime="
					+ startTime + ", endTime=" + endTime + ", duration(ms)=" + duration + ", throughput(B/ms)=" + throughput
					+ "]";
		}

		
}

		


