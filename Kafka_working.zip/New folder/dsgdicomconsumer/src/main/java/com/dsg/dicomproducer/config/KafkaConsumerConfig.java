package com.dsg.dicomproducer.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

@EnableKafka
@Configuration
public class KafkaConsumerConfig {

	@Value(value = "${kafka.bootstrapAddress}")
	private String bootstrapAddress;

	@Value(value = "${kafka.groupId}")
	private String groupId;

	@Value(value = "${sasl.jaas.config}")
	private String sasl_jaas_config;

	@Value(value = "${sasl.mechanism}")
	private String sasl_mechanism;

	@Value(value = "${security.protocol}")
	private String security_protocol;

	@Autowired
	ResourceLoader resourceLoader;

	@Bean
	public ConsumerFactory<String, String> consumerFactory() {
		System.out.println("KafkaConsumerConfig start-3");
		Map<String, Object> props = new HashMap<>();

		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		// Add additional properties.
		try {
			props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
					resourceLoader.getResource("classpath:ca.pem").getURI().getRawPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "PEM");
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.ByteArrayDeserializer");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.ByteArrayDeserializer");
		// props.put(ConsumerConfig.GROUP_ID_CONFIG, "dicom-consumer-2");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

		// additional
		props.put("sasl.jaas.config", sasl_jaas_config);
		props.put("sasl.mechanism", sasl_mechanism);
		props.put("security.protocol", security_protocol);

		System.out.println("KafkaConsumerConfig end-3");
		return new DefaultKafkaConsumerFactory<>(props);

//		bootstrap.servers=kafka-60ce7c10.svc-3.na1.cluster.hsdp.io:9092
//				key.serializer=org.apache.kafka.common.serialization.StringSerializer
//				value.serializer=org.apache.kafka.common.serialization.StringSerializer   
//				sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username="admin" password="c5cgbc41silzr6o6e4a2dvmq";
//				sasl.mechanism=PLAIN
//				security.protocol=SASL_SSL

	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {

		ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		return factory;
	}

}