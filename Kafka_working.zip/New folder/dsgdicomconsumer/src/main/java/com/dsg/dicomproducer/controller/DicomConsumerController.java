package com.dsg.dicomproducer.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsg.dicomproducer.service.ConsumerListenerService;
import com.dsg.dicomproducer.service.ConsumerService;


@RestController
@RequestMapping(value = "/diacom")
public class DicomConsumerController {
	@Autowired
	ConsumerService consumerService;
	@Autowired
	ConsumerListenerService consumerListener;
	
	@GetMapping(value = "/testapp")
	public String diacomTestApp() {
		
		return "Test successfully"+DicomConsumerController.class.getName();
	}
	
	
	@GetMapping(value = "/consumemessage/{name}")
	@ResponseBody
	  public String sendMessageToKafkaTopic(@PathVariable("name") String  name )  throws IOException {
		//consumerService.listenGroupFoo(name);
		
		return consumerService.consumeMessage(name).toString();
	  }
	


}
