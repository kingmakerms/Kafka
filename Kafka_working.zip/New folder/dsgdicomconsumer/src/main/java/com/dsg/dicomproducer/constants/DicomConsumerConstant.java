package com.dsg.dicomproducer.constants;

public class DicomConsumerConstant {
	
	 public final static String FILEPATH = "/home/vcap/app/dicom_output/output_daicom.jpg";
	 public final static String TOPIC_NAME = "dsg_dicom_proconsume";
	 public final static Integer FILE_BYTE = 5023177 ;
	 public static Long THROUGHPUT =0L;
	 public static int COUNT =0;
	 public static Long TIME_DIFFRENCE = 0L;

}
