package com.dsg.dicomproducer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;



public class ProducerTest {



	static int sizeMB = 1 * 1024 * 1024;
	static File theDir = null;



	public static void main(String[] args) {
		File currentDir = new File("C:\\Users\\VCHIRIPI\\Downloads\\DicomData");
		theDir = new File("C:\\Users\\VCHIRIPI\\Downloads\\OutputDicomData");
		if (!theDir.exists()) {
			theDir.mkdirs();
		}
		displayDirectoryFiles(currentDir);
	}



	public static void displayDirectoryFiles(File dir) {
		try {
			File[] files = dir.listFiles();
			for (File file : files) {
				String filePath = file.getCanonicalPath();
				int CurrentFilePointer = 0;
				readFromFile(filePath, CurrentFilePointer, sizeMB, theDir);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	private static void readFromFile(String filePath, int CurrentFilePointer, int chars, File theDir)
			throws IOException {
		RandomAccessFile file = new RandomAccessFile(filePath, "r");
		File fileName = new File(filePath);
		String folderName = theDir + "\\" + fileName.getName();
		File nf = new File(folderName);
		nf.mkdir();
		int i = 1;
		while (true) {
			byte returnData = 0;
			file.seek(CurrentFilePointer);
			byte[] bytes = new byte[chars];
			returnData = (byte) file.read(bytes);
			CurrentFilePointer = (int) file.getFilePointer();
			if (returnData == -1) {
				break;
			}
			if ((file.length() - (sizeMB * i) < sizeMB)) {
				chars = (int) (file.length() - (sizeMB * i));
			}



			writeFile(bytes, i, filePath, nf);
			i++;



		}



	}



	private static void writeFile(byte[] byteData, int i, String filePath, File nf) throws IOException {
		File file = new File(filePath);
		File outputFile = new File(nf + "//" + i + file.getName());
		FileOutputStream outputStream = new FileOutputStream(outputFile);
		outputStream.write(byteData);
		outputStream.close();
	}
}