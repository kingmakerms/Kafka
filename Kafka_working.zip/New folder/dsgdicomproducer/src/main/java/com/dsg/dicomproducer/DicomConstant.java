package com.dsg.dicomproducer;

import java.io.File;

import org.springframework.core.io.ClassPathResource;

public class DicomConstant {
	final static Integer SIZE_MB=999000;
	 final static String FILEPATH = "SampleJPGImage_1mbmb.jpg";
	 final static String TOPIC_KEY = "diacom2";
	  public static Long THROUGHPUT =0L;
		 public static int COUNT =0;
		 public static Long TIME_DIFFRENCE = 0L;
		 
		 public static Long FILE_SIZE =0L;
		 public static String FILE_NAME=null;

}
