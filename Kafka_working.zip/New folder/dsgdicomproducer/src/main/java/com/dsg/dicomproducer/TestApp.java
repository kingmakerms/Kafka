package com.dsg.dicomproducer;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;

import org.springframework.core.io.ClassPathResource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class TestApp {

	public static void main(String[] args) throws IOException {
		TestApp app=new TestApp();

	app.m1();
System.out.println("---------------------------------");
app.m2();
	}
	
	public void m1() {
		
		System.out.println("-------before-----------"+DicomConstant.THROUGHPUT);
		 DicomConstant.THROUGHPUT = 81018L;
			System.out.println("-------after-----------"+DicomConstant.THROUGHPUT);	
			
			double thro = DicomConstant.THROUGHPUT/1024/1024;
			System.out.printf("Value: %.4f", thro);
			
			System.out.println();
			double t = thro/1024;
			System.out.printf("Value t: %.4f", t);
			double mul = t*1000;
			System.out.printf("Value mul: %.4f", mul);
			
			double value = 0.077264;
			//System.out.printf("Value: %.4f", value);
		
	}
	public void m2() {
		System.out.println("-------after-m2----------"+DicomConstant.THROUGHPUT);	

	}

}
