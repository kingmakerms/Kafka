package com.dsg.dicomproducer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.springframework.stereotype.Component;

@Component
public class FileUtils {


	public static void splittingfile() throws IOException {
		// File filePath = new
		// File("C:\\Users\\MSINGOLE\\Downloads\\DicomData\\jmm_4377.jpg");
		File filePath = new File("C:\\Users\\SOWNDB\\Downloads\\jmm_4377.jpg");
		int sizeMB = 1 * 1024 * 1024;
		long fileSize = filePath.length();

		int sizecount = 0;
		int i;

		for (i = 0; i < fileSize / sizeMB; i++) {
			byte[] byteData = readFromFile(filePath, i * sizeMB, sizeMB);
			writeFile(byteData, i);

		}
		byte[] byteData = readFromFile(filePath, i * sizeMB, (int) (fileSize - (i * sizeMB)));
		writeFile(byteData, i);

	}



	public static byte[] readFromFile(File filePath, int seek, int chars) throws IOException {
		RandomAccessFile file = new RandomAccessFile(filePath, "r");
		file.seek(seek);
		// byte[] bytes = new byte[(int) filePath.length()];
		byte[] bytes = new byte[chars];
		file.read(bytes);
		file.close();
		return bytes;
	}

	public static void writeFile(byte[] byteData, int i) throws IOException {

		File outputFile = new File("C:\\Users\\SOWNDB\\Downloads\\Output_jmm_4377" + i + ".jpg");
		FileOutputStream outputStream = new FileOutputStream(outputFile);
		outputStream.write(byteData);
		outputStream.close();
	}

}
