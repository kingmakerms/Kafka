package com.dsg.dicomproducer;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Instant;

import org.springframework.core.io.ClassPathResource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class TestApp2 {

	public static void main(String[] args) {


		
		KafkaProducerService kafkaProducerService=new KafkaProducerService();
		try {
		//byte[] by=	kafkaProducerService.send("jmm_4377_5mb.jpg",999000);
		//System.out.println("TestApp2----------"+by.length);
			
			int sizeMb=999000;
			File filePath = null;
	    	
			try {
				filePath = new ClassPathResource("jmm_4377_5mb.jpg").getFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			long fileSize = filePath.length();
			log.info("--------------fileSize------------ " + fileSize);

			int CurrentFilePointer = 0;

			Instant startTime = Instant.now();
			log.info("--------------startTime------------ " + startTime);

			RandomAccessFile file;
		
				file = new RandomAccessFile(filePath, "r");
		
				byte[] bytes=null;
			int i = 1;
			//while (true) {
			int count =  (int)fileSize / sizeMb;
			log.info("--------------count------------ " + count);

			for ( i = 0; i <= count; i++) {
				log.info("----------first---i------------ " + i);

				
				byte returnData = 0;
				file.seek(CurrentFilePointer);
				bytes = new byte[sizeMb];

				returnData = (byte) file.read(bytes);

				CurrentFilePointer = (int) file.getFilePointer();

				if (returnData == -1 || sizeMb == 0) {

					break;
				}
				log.info("-------------bytessize------------ " + bytes.length);

				if ((file.length() - (sizeMb * i) < sizeMb)) {
					sizeMb = (int) (file.length() - (sizeMb * i));
					log.info("-------------leftover------------ " +sizeMb);

				}


		}} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

}
	
}
