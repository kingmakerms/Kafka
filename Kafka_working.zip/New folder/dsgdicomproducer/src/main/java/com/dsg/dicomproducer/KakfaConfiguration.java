package com.dsg.dicomproducer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class KakfaConfiguration {

	@Value(value = "${bootstrap.servers}")
	private String bootstrapAddress;

	@Value(value = "${sasl.jaas.config}")
	private String sasl_jaas_config;

	@Value(value = "${sasl.mechanism}")
	private String sasl_mechanism;

	@Value(value = "${security.protocol}")
	private String security_protocol;

	@Value(value = "${key.serializer}")
	private String key_serializer;
	
	@Value(value = "${value.serializer}")
	private String value_serializer;

	@Autowired
	ResourceLoader resourceLoader;

	@Bean
	public ProducerFactory<String, byte[]> producerFactory() {
		Map<String, Object> props = new HashMap<>();
		log.info("--------------------------------producerFactory--------------------");
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		try {
			props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
					resourceLoader.getResource("classpath:ca.pem").getURI().getRawPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "PEM");
		props.put(ProducerConfig.ACKS_CONFIG, "all");

		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, key_serializer);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, value_serializer);

		// additional
		props.put("sasl.jaas.config", sasl_jaas_config);
		props.put("sasl.mechanism", sasl_mechanism);
		props.put("security.protocol", security_protocol);
		log.info("---------------------------end-----producerFactory--------------------");

		return new DefaultKafkaProducerFactory<>(props);
	}

	@Bean
	public KafkaTemplate<String, byte[]> kafkaTemplate() {
		log.info("--------------------------kafkaTemplate-------------------");

		return new KafkaTemplate<>(producerFactory());
	}

}
