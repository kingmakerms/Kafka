package com.dsg.dicomproducer;

import org.apache.kafka.clients.producer.Producer;

public class KafkaProducerDto {

	public KafkaProducerDto() {
		// TODO Auto-generated constructor stub
	}
	
	
	public KafkaProducerDto(int i, byte[] byteData) {
		super();
	//	this.producer = producer;
		this.i = i;
		this.byteData = byteData;
	}

	//Producer<String, byte[]> producer;
	int i;
	byte[] byteData;
	
	
	
}
