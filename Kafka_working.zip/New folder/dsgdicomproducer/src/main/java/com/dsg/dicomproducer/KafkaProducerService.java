package com.dsg.dicomproducer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Duration;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class KafkaProducerService {
	private static final String TOPIC = "dsg_dicom_pro2";

	@Autowired
	private KafkaTemplate<String, byte[]> kafkaTemplate;
	// private static int sizeMB = 999000;
	@Autowired
	producerService producerService;
	@Autowired
	FileUtils fileUtils;

	public void publishMessage(String fileName, int sizeMB) throws IOException {

		log.info("--------------name------------ " + fileName);

		File filePath = null;

		try {
			filePath = new ClassPathResource(fileName).getFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		long fileSize = filePath.length();
		log.info("--------------fileSize------------ " + fileSize);

		int CurrentFilePointer = 0;

		Instant startTime = Instant.now();
		log.info("--------------startTime------------ " + startTime);

		RandomAccessFile file;
		try {
			file = new RandomAccessFile(filePath, "r");

			int i = 1;
			// while (true) {
			int count = (int) fileSize / sizeMB;
			log.info("--------------count------------ " + count);

			for (i = 0; i < count; i++) {
				log.info("----------first---i------------ " + i);

				byte returnData = 0;
				file.seek(CurrentFilePointer);
				byte[] bytes = new byte[sizeMB];

				returnData = (byte) file.read(bytes);

				CurrentFilePointer = (int) file.getFilePointer();

				if (returnData == -1 || sizeMB == 0) {

					break;
				}
				log.info("-------------bytessize------------ " + bytes.length);

				if ((file.length() - (sizeMB * i) < sizeMB)) {
					sizeMB = (int) (file.length() - (sizeMB * i));
					log.info("-------------leftover------------ " + sizeMB);

				}

				// sendProducer(producer, i, bytes);
				kafkaTemplate.send(TOPIC, "diacom2" + i, bytes);

				// i++;

			}
			@SuppressWarnings("static-access")
			byte[] byteData = fileUtils.readFromFile(filePath, i * sizeMB, (int) (fileSize - (i * sizeMB)));
			log.info("-------------leftover-----byteData------- " + byteData);

			if (byteData.length != 0) {
				kafkaTemplate.send(TOPIC, "diacom2" + i, byteData);

			}

			file.close();
			Instant endTime = Instant.now();
			log.info("--------time end------------" + endTime);
			DicomConstant.FILE_SIZE = fileSize;
			DicomConstant.FILE_NAME = filePath.getName();
			calculateFileThroughput(startTime, endTime);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String calculateFileThroughput(Instant startTime, Instant endTime) {
		log.info("-------calculateFileThroughput-----------");
		Long timeEla_sec = 0L;

		long fileSize = DicomConstant.FILE_SIZE;
		String fileName = DicomConstant.FILE_NAME;

		if (startTime != null && endTime != null) {
			Duration timeElapsed = Duration.between(startTime, endTime);
			timeEla_sec = timeElapsed.toMillis();
			DicomConstant.TIME_DIFFRENCE = DicomConstant.TIME_DIFFRENCE + timeEla_sec;

		}
		log.info("--------Throughput with milli----DicomConstant.TIME_DIFFRENCE -----------"
				+ DicomConstant.TIME_DIFFRENCE);

		DicomConstant.THROUGHPUT = fileSize / ((DicomConstant.TIME_DIFFRENCE * 1024 * 1024) / 1000);
		String return_str = "filename---" + fileName + "---" + "file_size---" + fileSize + "Bytes---" + "duration---"
				+ DicomConstant.TIME_DIFFRENCE * 0.001 + "s---" + "throughput(Mbps)---" + DicomConstant.THROUGHPUT;

		log.info("--------Throughput with milli------last----return_str---" + return_str);

		return return_str;

	}
}
