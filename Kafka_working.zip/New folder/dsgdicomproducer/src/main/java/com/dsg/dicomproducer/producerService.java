package com.dsg.dicomproducer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.errors.TopicExistsException;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class producerService {

	@Autowired
	ResourceLoader resourceLoader;

	final String topic = "dsg_dicom_proconsume";
	int sizeMB = 999000;

	public String sendMessage(String name) throws IOException {
		Resource resource = resourceLoader.getResource("classpath:producer.properties");
		final Properties props = loadConfig(resource);

		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
				resourceLoader.getResource("classpath:ca.pem").getURI().getRawPath());
		props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "PEM");
		props.put(ProducerConfig.ACKS_CONFIG, "all");

		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.ByteArraySerializer");
		createTopic(topic, props);

		Producer<String, byte[]> producer = new KafkaProducer<String, byte[]>(props);

		File filePath = new ClassPathResource("Sample_10mb.jpg").getFile();

		long fileSize = filePath.length();

		int CurrentFilePointer = 0;

		Instant startTime = Instant.now();
		log.info("--------------startTime------------ " + startTime);

		RandomAccessFile file = new RandomAccessFile(filePath, "r");

		int i = 1;
		//while (true) {
		int count =  (int)fileSize / sizeMB;

		for (i = 0; i < count; i++) {
			byte returnData = 0;
			file.seek(CurrentFilePointer);
			byte[] bytes = new byte[sizeMB];

			returnData = (byte) file.read(bytes);

			CurrentFilePointer = (int) file.getFilePointer();

			if (returnData == -1 || sizeMB == 0) {

				break;
			}
			log.info("-------------bytessize------------ " + bytes.length);

			if ((file.length() - (sizeMB * i) < sizeMB)) {
				sizeMB = (int) (file.length() - (sizeMB * i));
			}

			sendProducer(producer, i, bytes);
			i++;

		}
		file.close();
		producer.flush();
		producer.close();

		Instant endTime = Instant.now();
		log.info("--------time end------------" + endTime);
		DicomConstant.FILE_SIZE = fileSize;
		DicomConstant.FILE_NAME = filePath.getName();
		calculateFileThroughput(startTime, endTime);
		
		return filePath.getName();
	}

	public void sendProducer(Producer<String, byte[]> producer, int i, byte[] byteData) {

		producer.send(new ProducerRecord<String, byte[]>(topic, "diacom2" + i, byteData), new Callback() {
			@Override
			public void onCompletion(RecordMetadata m, Exception e) {
				if (e != null) {
					e.printStackTrace();
				} else {
					log.info("Produced record to topic %s partition [%d] @ offset %d%n", m.topic(), m.partition(),
							m.offset());

				}
			}
		});
	}

	public static Properties loadConfig(final Resource configFile) throws IOException {

		File file = configFile.getFile();
		final Properties cfg = new Properties();
		try (InputStream inputStream = new FileInputStream(file)) {
			cfg.load(inputStream);
		}
		return cfg;
	}

	public static void createTopic(final String topic, final Properties cloudConfig) {
		final NewTopic newTopic = new NewTopic(topic, Optional.empty(), Optional.empty());
		try (final AdminClient adminClient = AdminClient.create(cloudConfig)) {
			adminClient.createTopics(Collections.singletonList(newTopic)).all().get();
		} catch (final InterruptedException | ExecutionException e) {
			if (!(e.getCause() instanceof TopicExistsException)) {
				throw new RuntimeException(e);
			}
		}
	}

	

	public String calculateFileThroughput(Instant startTime, Instant endTime) {
		log.info("-------calculateFileThroughput-----------");
		Long timeEla_sec = 0L;

		long fileSize = DicomConstant.FILE_SIZE;
		String fileName = DicomConstant.FILE_NAME;

		if (startTime != null && endTime != null) {
			Duration timeElapsed = Duration.between(startTime, endTime);
			timeEla_sec = timeElapsed.toMillis();
			DicomConstant.TIME_DIFFRENCE = DicomConstant.TIME_DIFFRENCE + timeEla_sec;
			
		}
		log.info("--------Throughput with milli----DicomConstant.TIME_DIFFRENCE -----------"
				+ DicomConstant.TIME_DIFFRENCE);

		DicomConstant.THROUGHPUT = fileSize / ((DicomConstant.TIME_DIFFRENCE *1024 *1024) / 1000);
		String return_str = "filename---" + fileName + "---" + "file_size---" + fileSize + "Bytes---" + "duration---"
				+ DicomConstant.TIME_DIFFRENCE * 0.001 + "s---" + "throughput(Mbps)---" + DicomConstant.THROUGHPUT;


		log.info("--------Throughput with milli------last----return_str---" + return_str);

		return return_str;

	}
}
