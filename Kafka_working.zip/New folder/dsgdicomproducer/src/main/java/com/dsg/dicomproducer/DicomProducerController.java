package com.dsg.dicomproducer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/diacom")
public class DicomProducerController {
	@Autowired
	producerService producerService;
	@Autowired
	private KafkaTemplate<String, byte[]> kafkaTemplate;

	private static final String TOPIC = "dsg_dicom_pro2";
	private static int sizeMB = 999000;
	@Autowired
	FileUtils fileUtils;
	@Autowired
	KafkaProducerService kafkaProducerService;

	@SuppressWarnings("rawtypes")
	@PostMapping(value = "/publish")
	public String sendMessageToKafkaTopic(@RequestParam("name") String name) throws IOException {
		// User user=new User(name);

		return producerService.sendMessage(name).toString() + "Successfully pushed";

	}

	@GetMapping("/throughput")
	public String throughput() throws InterruptedException {
		return producerService.calculateFileThroughput(null, null);
	}

	/*

	@PostMapping("/sendkafkamsg/{name}")
	public String post(@PathVariable("name") final String name) {
		log.info("--------------name------------ " + name);

		File filePath = null;

		try {
			filePath = new ClassPathResource("jmm_4377_5mb.jpg").getFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		long fileSize = filePath.length();
		log.info("--------------fileSize------------ " + fileSize);

		int CurrentFilePointer = 0;

		Instant startTime = Instant.now();
		log.info("--------------startTime------------ " + startTime);

		RandomAccessFile file;
		try {
			file = new RandomAccessFile(filePath, "r");

			int i = 1;
			// while (true) {
			int count = (int) fileSize / sizeMB;
			log.info("--------------count------------ " + count);

			for (i = 0; i < count; i++) {
				log.info("----------first---i------------ " + i);

				byte returnData = 0;
				file.seek(CurrentFilePointer);
				byte[] bytes = new byte[sizeMB];

				returnData = (byte) file.read(bytes);

				CurrentFilePointer = (int) file.getFilePointer();

				if (returnData == -1 || sizeMB == 0) {

					break;
				}
				log.info("-------------bytessize------------ " + bytes.length);

				if ((file.length() - (sizeMB * i) < sizeMB)) {
					sizeMB = (int) (file.length() - (sizeMB * i));
					log.info("-------------leftover------------ " + sizeMB);

				}

				// sendProducer(producer, i, bytes);
				kafkaTemplate.send(TOPIC, "diacom2" + i, bytes);

				// i++;

			}
			byte[] byteData = fileUtils.readFromFile(filePath, i * sizeMB, (int) (fileSize - (i * sizeMB)));
			log.info("-------------leftover-----byteData------- " + byteData);

			if (byteData.length != 0) {
				kafkaTemplate.send(TOPIC, "diacom2" + i, byteData);

			}

			file.close();
			Instant endTime = Instant.now();
			log.info("--------time end------------" + endTime);
			DicomConstant.FILE_SIZE = fileSize;
			DicomConstant.FILE_NAME = filePath.getName();
			producerService.calculateFileThroughput(startTime, endTime);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "Published successfully";
	}
	*/
	@PostMapping("/publish-kafka-message")
	public String post(@RequestParam("filename") final String filename,@RequestParam("sizemb")Integer sizemb) {
		
		try {
			kafkaProducerService.publishMessage(filename, sizemb);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Published successfully";
	}
	
	
	
}
